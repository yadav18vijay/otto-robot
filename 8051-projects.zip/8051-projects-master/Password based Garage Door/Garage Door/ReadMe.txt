case 1: General case (Password is 1234)
To open the Garage door, Dial *1234*
To close the Garage door, Dial #1234#
-----------------------------------------








