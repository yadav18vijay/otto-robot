# 8051 Projects
8051 Micrcontroller based project Codes and Simulations

These projects were done by me in College. Not all projects were implemented but they had been tested. I have implemented 70% of them. I mean with Hardware.
Remaining were simulated using Proteus.
